<section id="zpituheader">
 <div id="menucuerpo">
    <nav id="menu" class="navbar navbar-default">
    <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand " href="#" style="text-align: right;">Archivo</a><div style="text-align: right;"><br></div></div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="inicio">INICIO</a></li>
        <li><a href="empresa">EMPRESA</a></li> 
        <li><a href="blog">BLOG</a></li>
        <li><a href="contacto">CONTACTO</a></li>
      </ul>
    </div>
  </div>
</nav>
<!-- First Container -->
<div id="cabecera" class="container">
  <h3 class="margin" style="text-align: center;">¿Quieres a Juan?</h3>
  <div style="text-align: center; background-color: rgba(68, 238, 204, 0.933);">
    <img src="https://ziw.es/subdominio/000.zpt.es/imagen/simple1.jpg" class="img-circle" alt="Bird" style="width:30%;margin:5px;"></div>
    <h3 style="text-align: center; ">¿Amas a la vida?</h3>
</div>
</div> 
</section>