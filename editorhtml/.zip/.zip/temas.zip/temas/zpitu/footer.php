<section id="zpitufooter">
    <div class="container-fluid bg-4 text-center" style="background-color: rgba(17, 0, 238, 0.933);">
    <div class="row" style="display: flex; flex-wrap: wrap; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont,">
        <div class="col-md-4 " style="width: 566.132px; flex: 0 0 33.3333%; max-width: 33.3333%; background-color: rgba(255, 255, 255, 0.933);">
            <h4 style="margin-top: 0px; margin-bottom: 0.5rem; line-height: 1.2; font-size: 1.5rem;">Redes sociales</h4>
            <p style="margin-bottom: 1rem; background-color: rgba(17, 0, 238, 0.933);" class="">
                <a href="https://www.facebook.com/zetapitu" target="_blank" style="color: rgb(0, 123, 255);">
                    <img class="icon-pie" src="https://ziw.es/images/iconos/facebook.png" style="border-style: none; width: 30px; height: 30px;"></a>
            </p>
            <p style="margin-bottom: 1rem;">
                <a href="https://twitter.com/zetapitu" target="_blank" style="color: rgb(0, 123, 255);">
                    <img class="icon-pie" src="https://ziw.es/images/iconos/gorjeo.png" style="border-style: none; width: 30px; height: 30px;"></a>
            </p>
            <p style="margin-bottom: 1rem;">
                <a href="https://www.linkedin.com/in/zetapitu/" target="_blank" style="color: rgb(0, 123, 255);">
                    <img class="icon-pie" src="https://ziw.es/images/iconos/linkedin.png" style="border-style: none; width: 30px; height: 30px;"></a>
            </p>
            <p style="margin-bottom: 1rem;" class="">Recuerda somos una entidad benéfica</p>

        </div>
        <div class="col-md-4" style="width: 566.132px; flex: 0 0 33.3333%; max-width: 33.3333%; background-color: rgba(221, 221, 68, 0.933);">
            <h1 style="margin-top: 0px; margin-bottom: 0.5rem; line-height: 1.2; font-size: 2.5rem;"></h1>
            <div id="fb-root">
                <div class="fb-share-button" data-href="https://ziw.es" data-layout="button" data-size="small"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fziw.es%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore" style="color: rgb(0, 123, 255);">Compartir</a></div>
            </div>
            <img src="https://ziw.es/images/tema3.jpg" style="width: 30%; margin: 5px;" class="">
        </div>
        <div class="col-md-4" style="width: 566.132px; flex: 0 0 33.3333%; max-width: 33.3333%; background-color: rgba(255, 255, 255, 0.933);">
            <h4 style="margin-top: 0px; margin-bottom: 0.5rem; line-height: 1.2; font-size: 1.5rem;">Contacto</h4>
            <p style="margin-bottom: 1rem;" class="">📧&nbsp;info@ziw.es</p>
            <p style="margin-bottom: 1rem;">📞 +34 663 56 60 29</p>
            <p style="margin-bottom: 1rem;" class=""><a href="https://zpitu.com/" style="color: black;">Web de ZetaPitu</a></p>
            <p style="margin-bottom: 1rem;"><a href="https://ziw.es/editorhtml/editorhtml.php#" style="color: black;">Volver a inicio</a></p>
            <a name="contacto" style="color: inherit;"></a>
        </div>
        <a name="contacto" style="color: inherit;"></a>
    </div>
    <a name="contacto" style="color: rgb(33, 37, 41); background-color: rgb(157, 126, 83);"></a>
    <p style="margin-bottom: 1rem; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont,"></p>
    <a name="contacto" style="color: inherit;"></a>
    <a href="https://ziw.es/privacidad.html" target="_blank" style="color: rgba(255, 255, 255, 0.933);" class="">Privacidad y cookies&nbsp;&nbsp;ZetaPitu © 2019</a>
</div>
    <div id="cookies-ziw" style="position: fixed; top: 0px; left: 0px; z-index: 2147483647; background-color: rgb(0, 148, 255); color: rgb(255, 255, 255); height: 0px; overflow: hidden; display: block;">
        Utilizamos cookies propias y de terceros para obtener datos estadísticos de la navegación de nuestros usuarios y
        mejorar nuestros servicios. Si acepta o continúa navegando, consideramos que acepta su uso. Puede cambiar la configuración
        u obtener más información aquí &nbsp;&nbsp; <a style="color: burlywood" href="https://ziw.es/privacidad.html" target="_blank">Cookies</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <button onclick="cerrarcookies()" style="background-color: #ff0000; color: blanchedalmond">Aceptar</button>
    </div>
</section>