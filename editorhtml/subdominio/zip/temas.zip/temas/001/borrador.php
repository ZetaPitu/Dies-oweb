<!DOCTYPE HTML>
<!--
	Strata by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html lang="es">
	<head>
		<title>Borrador</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="https://ziw.es/subdominio/prueba.ziw.es/temas/001/assets/css/main.css" />
        <!-- Scripts -->
			<script src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/assets/js/jquery.min.js"></script>
			<script src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/assets/js/jquery.poptrox.min.js"></script>
			<script src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/assets/js/browser.min.js"></script>
			<script src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/assets/js/breakpoints.min.js"></script>
			<script src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/assets/js/util.js"></script>
			<script src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/assets/js/main.js"></script>
	
	</head>
<body>

   


    <header id="header"><content>div </content>

				<div class="inner" style="border:none">
					<a href="#" class="image avatar"><img src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/images/avatar.jpg" alt=""></a>
					<h1>Presentando su primera plantilla web hecha a mano por&nbsp;<a href="https://zpitu.es/servicios">ZetaPitu</a>.</h1>
				</div>
			</header>

		<!-- Main -->
			<div id="main" style="border:none">

				<!-- One -->
					<section id="one">
						<header class="major">
							<h2><font color="#008040">Ju Mascuñano dolores aliquam ante commodo<br>
							mañana sed <span style="font-size:110%;width: 20px;height: 20px;"><span style="font-size:110%;width: 20px;height: 20px;"><span style="font-size:110%;width: 20px;height: 20px;"><span style="font-size:110%;width: 20px;height: 20px;"><span style="font-size:110%;width: 20px;height: 20px;"><span style="font-size:110%;width: 20px;height: 20px;"><span style="font-size:110%;width: 20px;height: 20px;"><span style="font-size:110%;width: 20px;height: 20px;"><span style="font-size:110%;width: 20px;height: 20px;"><span style="font-size:110%;width: 20px;height: 20px;"><span style="font-size:110%;width: 20px;height: 20px;"><span style="font-size:110%;width: 20px;height: 20px;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;">ac</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span>cumsan</span></span></span></span></span></span></span></span></span></span></span></span> arcu neque.gggggg</font><span style="font-size:90%;"><span style="font-size:90%;"><span style="font-size:90%;"></span></span></span></h2>
						</header>
						<p><span style="background-color: rgb(128, 255, 0);">Accumsan orci faucibus id eu lorem semper. Eu ac iaculis ac nunc nisi lorem vulputate lorem neque cubilia ac in adipiscing in curae lobortis tortor primis integer massa adipiscing id nisi accumsan pellentesque commodo blandit enim arcu non at amet id arcu magna. Accumsan orci faucibus id eu lorem semper nunc nisi lorem vulputate lorem neque cubilia.</span></p>
						<ul class="actions">
							<li><a href="#" class="button">Learn More</a><iframe src="https://www.youtube.com/embed/cMgAD4K2i0U" style="width: 100%; height: 480px;"></iframe></li>
						</ul>
					</section>

				<!-- Two -->
					<section id="two">
						<h2 style="text-align: center;">Recent Work</h2>
						<div class="row">
							<article class="col-6 col-12-xsmall work-item">
								<a class="image fit thumb" style="cursor: pointer; outline: 0px;"><img src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/mages/thumbs/01.jpg" alt=""></a>
								<h3>Juan Mascuñano Torres</h3><div><div><iframe style="width:100%;height:480px" src="https://www.youtube.com/embed/2j7G4vxoDF8"></iframe></div></div>
								<p>Esto es una muestra de las 1000 que existen</p>
							</article>
							<article class="col-6 col-12-xsmall work-item">
								<a class="image fit thumb" style="cursor: pointer; outline: 0px;"><img src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/images/thumbs/02.jpg" alt=""></a>
								<h3>Ultricies lacinia interdum</h3>
								<p>Lorem ipsum dolor sit amet nisl sed nullam feugiat.</p>
							</article>
							<article class="col-6 col-12-xsmall work-item">
								<a class="image fit thumb" style="cursor: pointer; outline: 0px;"><img src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/images/thumbs/03.jpg" alt=""></a>
								<h3>Tortor metus commodo</h3>
								<p>Lorem ipsum dolor sit amet nisl sed nullam feugiat.</p>
							</article>
							<article class="col-6 col-12-xsmall work-item">
								<a class="image fit thumb" style="cursor: pointer; outline: 0px;"><img src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/images/thumbs/04.jpg" alt=""></a>
								<h3>Quam neque phasellus</h3>
								<p>Lorem ipsum dolor sit amet nisl sed nullam feugiat.</p>
							</article>
							<article class="col-6 col-12-xsmall work-item">
								<a class="image fit thumb" style="cursor: pointer; outline: 0px;"><img src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/images/thumbs/05.jpg" alt=""></a>
								<h3>Nunc enim commodo aliquet</h3>
								<p>Lorem ipsum dolor sit amet nisl sed nullam feugiat.</p>
							</article>
							<article class="col-6 col-12-xsmall work-item">
								<a class="image fit thumb" style="cursor: pointer; outline: 0px;"><img src="https://ziw.es/subdominio/prueba.ziw.es/temas/001/images/thumbs/06.jpg" alt=""></a>
								<h3>Risus ornare lacinia</h3>
								<p>Lorem ipsum dolor sit amet nisl sed nullam feugiat.</p>
							</article>
						</div>

						<ul class="actions">
							<li><a href="#" class="button">Full Portfolio</a></li>
						</ul>
					</section>

				<!-- Three -->
					<section id="three">
						<h2>Get In Touch</h2>
						<p>Accumsan pellentesque commodo blandit enim arcu non at amet id arcu magna. Accumsan orci faucibus id eu lorem semper nunc nisi lorem vulputate lorem neque lorem ipsum dolor.</p>
						<div class="row">
							<div class="col-8 col-12-small">
								<form method="post" action="#">
									<div class="row gtr-uniform gtr-50">
										<div class="col-6 col-12-xsmall"><input type="text" name="name" id="name" placeholder="Name"></div>
										<div class="col-6 col-12-xsmall"><input type="email" name="email" id="email" placeholder="Email"></div>
										<div class="col-12"><textarea name="message" id="message" placeholder="Message" rows="4"></body>
</html>
</body>
</html></textarea></div></div></form></div></div></section></div><div class="poptrox-overlay" style="position: fixed; left: 0px; top: 0px; z-index: 1000; width: 100%; height: 100%; text-align: center; cursor: pointer; display: none;"><div style="display:inline-block;height:100%;vertical-align:middle;"></div><div style="position:absolute;left:0;top:0;width:100%;height:100%;background:#2c2c2c;opacity:0.85;filter:alpha(opacity=85);"></div><div class="poptrox-popup" style="display: none; vertical-align: middle; position: relative; z-index: 1; cursor: auto; min-width: 200px; min-height: 100px;"><div class="loader" style="display: none;"></div><div class="pic" style="display: none;"></div><div class="caption" style="display: none;"></div><span class="closer" style="cursor: pointer; display: none;"></span><div class="nav-previous" style="display: none;"></div><div class="nav-next" style="display: none;"></div></div></div><div class="poptrox-overlay" style="position: fixed; left: 0px; top: 0px; z-index: 1000; width: 100%; height: 100%; text-align: center; cursor: pointer; display: none;"><div style="display:inline-block;height:100%;vertical-align:middle;"></div><div style="position:absolute;left:0;top:0;width:100%;height:100%;background:#2c2c2c;opacity:0.85;filter:alpha(opacity=85);"></div><div class="poptrox-popup" style="display: none; vertical-align: middle; position: relative; z-index: 1; cursor: auto; min-width: 200px; min-height: 100px;"><div class="loader" style="display: none;"></div><div class="pic" style="display: none;"></div><div class="caption" style="display: none;"></div><span class="closer" style="cursor: pointer; display: none;"></span><div class="nav-previous" style="display: none;"></div><div class="nav-next" style="display: none;"></div></div></div><div class="poptrox-overlay" style="position: fixed; left: 0px; top: 0px; z-index: 1000; width: 100%; height: 100%; text-align: center; cursor: pointer; display: none;"><div style="display:inline-block;height:100%;vertical-align:middle;"></div><div style="position:absolute;left:0;top:0;width:100%;height:100%;background:#2c2c2c;opacity:0.85;filter:alpha(opacity=85);"></div><div class="poptrox-popup" style="display: none; vertical-align: middle; position: relative; z-index: 1; cursor: auto; min-width: 200px; min-height: 100px;"><div class="loader" style="display: none;"></div><div class="pic" style="display: none;"></div><div class="caption" style="display: none;"></div><span class="closer" style="cursor: pointer; display: none;"></span><div class="nav-previous" style="display: none;"></div><div class="nav-next" style="display: none;"></div></div></div>
</body>
</html>